
class Engine:

    def __init__ (self):
        self.mass = 1338500 #Massa de combustível
        self.nEngine = 0.0 ##Número de motores em trabalho ##
        self.enginethrust = 903000 ##Empuxo de cada motor
        self.enginec = 320.0 ##Consumo de Massa de cada motor em Kg/s
