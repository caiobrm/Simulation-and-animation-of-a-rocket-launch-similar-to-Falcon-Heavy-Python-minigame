import pygame
import math
class database:
    def __init__(self):
        self.g = -9.80665 ## Aceleração Gravitacional
        FPS = 60
        self.fps = 60
        self.t = (1/FPS)
        self.speed_y = 0
        self.pos_x = 668
        self.pos_y = -384
        self.G = 6.674184*math.pow(10,-11)
        self.Mt = 5.972*math.pow(10,24)
        self.Rt = 6371000
        self.str1 = 'Velocidade : {0:+4.3f} m/s'
        self.str2 = 'Velocidade : {0:+4.3f} km/h'
        self.str3 = 'Combustível : {0:4.2f} kg'
        self.str4 = 'Altitude : {0:4.1f} m'
        ##Screen
        self.large = 1366   
        self.high = 768

class colors:
    def __init__(self):
        self.white = (255,255,255)
        self.red = (255,0,0)
        self.green = (0,255,0)
        self.blue = (0,0,255)
        self.black = (0,0,0)
        self.blue1 = (0,182,255)
