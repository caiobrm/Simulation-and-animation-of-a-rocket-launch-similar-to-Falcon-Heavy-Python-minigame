from database import database
from Rocket import Rocket
from Engine import Engine
rocket = Rocket()
engine = Engine()
class dynamics:

    def __init__(self):
        self.ft = 0 ##Força de Empuxo de cada motor
        self.alt = 0.0 ##Altitude
        self.v1 = 0.0 ## Velocidade Final
        self.a = 0.0 ## Aceleração resultante
        self.vr = 0.0 ##Velocidade Final em escala
        self.vry = 0.0
        self.mflow = 0 ##Massa total consumida pelos motores em Kg/s
        ##Drag (arrasto)
        self.drag = 0.0
        ##Força Peso
        self.p = 0 


dyn = dynamics()

def fthrust(nEngine, enginethrust):
    return nEngine*enginethrust
def masst(mass, massc):
    return mass + massc
def grav(alt):
    from database import database
    data = database()
    g = (data.G*data.Mt)/(alt+data.Rt)**2
    return g
def dragforce(v1):
    rocket = Rocket()
    drag = (rocket.Cx*rocket.Ar*v1**2)/2
    return drag
def pforce(mass, alt):
    data = database()
    data.g = grav(alt)
    p = mass * data.g
    return p
def rforce(nEngine, enginethrust, v1, mass, alt):
    if v1 < 0:
        a = (fthrust(nEngine, enginethrust) +dragforce(v1) -pforce(mass,alt))/mass
        return a
    a = (fthrust(nEngine, enginethrust) -dragforce(v1) -pforce(mass,alt))/mass
    return a