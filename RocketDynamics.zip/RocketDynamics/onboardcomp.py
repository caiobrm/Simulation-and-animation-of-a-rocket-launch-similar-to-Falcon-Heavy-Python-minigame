import pygame
from database import database
from database import colors

def text(backgrd, msg, cor, tam, x, y):
    font = pygame.font.SysFont(None, 30)
    texto1 = font.render(msg, True, cor)
    backgrd.blit(texto1,[x, y])

class onboardcomp:
    def __init__(self,backgrd,v1,alt,mass,large,high):
        ##DISPLAY
        data1 = database()
        color = colors()
        text(backgrd,data1.str1.format(v1), color.white, 15, large/10, high/10)
        text(backgrd,data1.str2.format(v1*3.6), color.white, 15, large/10, high/15)
        text(backgrd,data1.str3.format(mass), color.white, 15, large/10, high/7.5)
        text(backgrd,data1.str4.format(alt), color.white, 15, large/10, high/6)