
class Engine:

    def __init__ (self):
        self.mass = 1338500 #Massa de combustível
        self.nEngine = 0 ##Número de motores em trabalho ##
        self.enginethrust = 903000 ##Empuxo de cada motor
        self.enginec = 320 ##Consumo de Massa de cada motor em Kg/s

def epower(v1):
    if v1 > 5 and v1 < 25:
        return 24
    if v1 > 25 and v1 < 140:
        return 24
    if v1 > 140:
        return 23