import pygame
from Rocket import Rocket
from Engine import Engine
from database import colors
from database import database
from onboardcomp import onboardcomp
from Dynamics import dynamics
from Dynamics import fthrust
from Dynamics import masst
from Dynamics import grav
from Dynamics import dragforce
from Dynamics import pforce
from Engine import epower
from Dynamics import rforce
import math

##########

Rocket = Rocket()
engine = Engine()
color = colors()
data = database()

try:
    pygame.init()
except:
    print("O módulo pygame não foi iniciado corretamente.\n")
##FuncTime
tokei = pygame.time.Clock()
##EndFuncTime
backgrd = pygame.display.set_mode((data.large,data.high))
icon = pygame.image.load('img\\Logo1.png')
pygame.display.set_icon(icon)
pygame.display.set_caption("Rocket Dynamics",)

def game():
    ##
 mass =  masst(Rocket.massc, engine.mass)
 dyn = dynamics()
 data = database()
    ##
 sair = True
 while sair:
     ##Movements##
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sair = False
    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_SPACE:
            data.speed_y = 0
        if event.key == pygame.K_UP: ##ACELERADOR
                dyn.v1 = (dyn.v1 + (dyn.a*data.t))
                dyn.vr = dyn.v1/50   
                engine.nEngine = 24
                dyn.alt = dyn.alt + dyn.v1*data.t + ((dyn.a*data.t**2)/2)  
                engine.mass = engine.mass - dyn.mflow*data.t 
                data.speed_y=-dyn.vr
    if event.type == pygame.KEYUP:
        if event.key == pygame.K_UP:
             dyn.v1 = dyn.v1 + dyn.a*data.t
             dyn.vry = dyn.v1/50
             engine.nEngine = 0
             dyn.alt = dyn.alt + dyn.v1*data.t + ((dyn.a*data.t**2)/2)  
             data.speed_y =-dyn.vry

    backgrd.fill(color.black)
    pygame.draw.circle(backgrd, color.white, [int(data.pos_x),int(data.pos_y)],Rocket.size)
    data.pos_y+=data.speed_y
    ##Determina a força de Empuxo em relação ao número de motores

    ##ATUALIZAÇÕES## 
    dyn.a = rforce(engine.nEngine, engine.enginethrust, dyn.v1, mass, dyn.alt)
    dyn.mflow = engine.enginec*engine.nEngine
    mass = masst(Rocket.massc, engine.mass)
    print(engine.nEngine)

    if dyn.alt < 0:
        data.pos_y = -384
        dyn.alt = 0.0
        dyn.v1 = 0.0
        engine.mass = 1338000
        dyn.vry = 0.0

    ##DISPLAY
    pygame.draw.rect(backgrd, color.blue1, [125, 37, 300,125], )
    onboardcomp(backgrd,dyn.v1,dyn.alt,engine.mass,data.large,data.high)

    tokei.tick(data.fps)

    if data.pos_x > data.large:
        data.pos_x = 0
    if data.pos_x < 0:
        data.pos_x = data.large - Rocket.size
    if data.pos_y >= data.high:
        data.pos_y = 0
    if data.pos_y < 0:
        data.pos_y = data.high - Rocket.size

    pygame.display.update()

game()